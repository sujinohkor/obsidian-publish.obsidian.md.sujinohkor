# Tutorial: My First Firefox Extension with an LLM Service (Simple Version)

**Goal:** Build a Firefox extension that changes a webpage's background color and uses an LLM to explain the page in one Korean sentence.

## Step 1. Create the project files

Create a folder named **my-first-firefox-extension** on your computer. Inside this folder, create the following two files:

- **manifest.json**: Defines the extension's metadata, permissions, and background scripts.
- **background.js**: Defines what happens when the user clicks the extension's icon.

The example package also includes **cloudflare/worker.js**, which runs on Cloudflare rather than in Firefox. No npm installation is required.

## Step 2. Prepare an OpenAI API key

1. Visit **https://platform.openai.com/api-keys** and create an API key.
2. Make sure your OpenAI API account has access to API billing or credits. ChatGPT subscriptions and API usage are billed separately.
3. **Do not put the OpenAI API key in the extension's source code.** It will be stored as a Cloudflare Worker secret.

## Step 3. Create a Cloudflare Worker

1. Open **https://dash.cloudflare.com/**.
2. Go to **Workers & Pages** and create a new Worker. The menu wording may vary.
3. Open the Worker's code editor and replace its contents with **cloudflare/worker.js**.
4. Click **Deploy** and copy the Worker's HTTPS URL (for example, `https://page-summary.your-subdomain.workers.dev`).
5. Open that URL in a browser. A JSON message saying **Worker is running** confirms that the Worker is deployed, but does not yet confirm access to OpenAI.

## Step 4. Set two Worker secrets

Open the Worker's **Settings → Variables and Secrets** and add these values as **Secret** variables:

- **OPENAI_API_KEY**: Your OpenAI API key.
- **DEMO_TOKEN**: A newly generated random string of at least 32 characters.

Save and deploy the changes. The demo token is a simple access token for the practice Worker; it is **not** an OpenAI API key.

## Step 5. Configure the Firefox extension

Open **my-first-firefox-extension/background.js** and replace the first two placeholders:

```javascript
const WORKER_URL = "https://page-summary.your-subdomain.workers.dev";
const DEMO_TOKEN = "YOUR_RANDOM_TOKEN_AT_LEAST_32_CHARACTERS";
```

Use your actual Worker URL and the **same** demo token you saved in Cloudflare.

Next, open **my-first-firefox-extension/manifest.json** and update `host_permissions` to match your Worker URL:

```json
"host_permissions": ["https://page-summary.your-subdomain.workers.dev/*"]
```

**Do not include your OpenAI API key in either extension file.**

## Step 6. Load the extension in Firefox

After saving both extension files, follow these steps to load the extension in Firefox.

1. Enter **about:debugging** in Firefox's address bar.
2. Select **This Firefox** from the left sidebar.
3. Click **Load Temporary Add-on**.
4. Open the **my-first-firefox-extension** folder and select **manifest.json**.

If **My First Firefox Extension + LLM** appears under **Temporary Extensions**, the extension has loaded successfully. You can now run it locally without publishing it to Firefox Add-ons.

**Note:** Firefox removes temporary extensions when the browser is completely restarted. You must load the extension again after restarting Firefox.

## Step 7. Run the extension

1. Open **https://example.com** in a new tab.
2. Click the puzzle-shaped **Extensions** button in the top-right corner of Firefox.
3. Select **My First Firefox Extension + LLM**.
4. When a confirmation dialog appears, click **OK** to send the page's title and up to 6,000 characters of text to Cloudflare and OpenAI.
5. If the page's background turns light yellow, the script ran successfully.
6. When the LLM finishes, a dialog displays a **one-sentence Korean description** of the page.

**Important:** A yellow background only confirms that the webpage script ran. The LLM connection is successful **only if the summary dialog appears**.

## Step 8. Reload after making changes

1. Save changes to `background.js` or `manifest.json`.
2. Open **about:debugging → This Firefox**.
3. Click **Reload** under your temporary extension.
4. Refresh the test webpage and run the extension again.

To investigate errors, click **Inspect** for the extension in `about:debugging` and check the console.

## Troubleshooting

- **Setup warning:** Update `WORKER_URL`, `DEMO_TOKEN`, and `host_permissions`, then reload the extension.
- **Invalid demo token:** Make sure the token matches the Worker secret.
- **OpenAI HTTP 401:** Check your OpenAI API key.
- **OpenAI HTTP 429:** Check API billing, credits, or rate limits.
- **Failed to fetch:** Check the Worker URL, deployment, Firefox host permission, and extension manifest.
- **Timeout:** Try again. A request may still incur API charges if it was processed before the timeout.
- **Nothing happens:** Try a standard HTTPS webpage, then inspect the extension's console. Some internal Firefox pages do not allow extensions to run scripts.

## What changed from Chrome?

| Chrome extension | Firefox extension |
| --- | --- |
| `"background": { "service_worker": "background.js" }` | `"background": { "scripts": ["background.js"] }` |
| `chrome.action.onClicked` | `browser.action.onClicked` |
| `chrome.scripting.executeScript()` | `browser.scripting.executeScript()` |
| `chrome://extensions` | `about:debugging` |
| Load unpacked / select folder | Load Temporary Add-on / select `manifest.json` |

**Scope:** This introductory example extracts part of a webpage and requests a one-sentence summary. It does **not** implement content grouping, a suggested reading order, or NVDA virtual-cursor synchronization. Test only on public pages because visible text can contain personal information.

**Official documentation**

- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/background
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/executeScript
- https://firefox-source-docs.mozilla.org/devtools-user/about_colon_debugging/
- https://developers.cloudflare.com/workers/configuration/secrets/
