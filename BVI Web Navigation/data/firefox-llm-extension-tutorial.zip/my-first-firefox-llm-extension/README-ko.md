# Firefox Extension + LLM Service (Simple Version)

기존 Chrome 예제(`llm-extension-tutorial(1).zip`)의 기능을 Firefox Manifest V3용으로 변환한 **개인 실습용** 예제입니다.

## 이 예제에서 하는 일

1. Firefox의 확장 프로그램 버튼을 클릭합니다.
2. 현재 웹페이지의 제목과 본문 앞부분(최대 6,000자)을 외부 서비스로 보낼지 확인합니다.
3. 승인하면 웹페이지의 배경색을 연한 노란색(`#fff3b0`)으로 변경합니다.
4. Cloudflare Worker가 요청의 DEMO_TOKEN을 검사하고 OpenAI Responses API(`gpt-4.1-mini`)로 내용을 전달합니다.
5. LLM이 생성한 **한국어 한 문장 설명**을 웹페이지의 알림창에 표시합니다.

**중요:** 이 예제는 NVDA용 읽기 순서 변경, 콘텐츠 그룹화, 시각적 중요도 분석을 아직 구현하지 않습니다.

## 폴더 구조

```text
my-first-firefox-llm-extension/
├── my-first-firefox-extension/
│   ├── manifest.json       # Firefox 확장 프로그램 설정
│   └── background.js       # 아이콘 클릭 시 페이지 추출 및 Worker 호출
├── cloudflare/
│   └── worker.js           # Cloudflare Worker에 배포할 서버 코드
├── README-ko.md            # 이 설명서
└── TUTORIAL-en.md          # PPT용 영어 튜토리얼
```

## 1. OpenAI API 키 준비

1. https://platform.openai.com/api-keys 에 로그인하여 API 키를 발급합니다.
2. 사용 가능한 API 크레딧/결제 설정을 확인합니다. **ChatGPT 유료 구독과 OpenAI API 요금은 별도**입니다.
3. API 키는 확장 프로그램 코드에 **절대로 넣지 마십시오.** 아래 Cloudflare Worker Secret으로 설정합니다.

## 2. Cloudflare Worker 만들기

1. https://dash.cloudflare.com/ 에 로그인합니다.
2. **Workers & Pages → Create**에서 새로운 Worker를 만듭니다. 메뉴 이름은 화면 버전에 따라 조금 다를 수 있습니다.
3. Worker 편집 화면에서 `cloudflare/worker.js`의 **전체 내용**을 붙여 넣고 배포(Deploy)합니다.
4. 생성된 HTTPS 주소를 복사합니다. 예: `https://page-summary.your-subdomain.workers.dev`
5. 해당 Worker URL을 브라우저에서 열어 `Worker is running` 메시지가 표시되는지 확인합니다.

> 이 단계는 Worker가 작동하는지만 검사합니다. OpenAI API와의 연결 확인은 아닙니다.

## 3. Cloudflare Worker Secret 설정

Worker의 **Settings → Variables and Secrets**에서 아래 두 값을 **Secret**으로 추가하고 배포합니다.

| 이름 | 값 |
| --- | --- |
| `OPENAI_API_KEY` | 발급한 실제 OpenAI API 키 |
| `DEMO_TOKEN` | 직접 만든 32자 이상의 무작위 문자열 |

`DEMO_TOKEN`은 간단한 실습용 Worker 접속 암호입니다. OpenAI API 키와 다릅니다.

## 4. Firefox Extension 설정

`my-first-firefox-extension/background.js`의 맨 위를 열어 다음 두 항목을 수정합니다.

```javascript
const WORKER_URL = "https://page-summary.your-subdomain.workers.dev";
const DEMO_TOKEN = "CLOUDFLARE_SECRET과_일치하는_무작위_토큰_32자_이상";
```

- `WORKER_URL`: **본인의** Worker URL로 변경합니다. 끝에 `/*`를 넣지 않습니다.
- `DEMO_TOKEN`: 3단계의 Secret과 정확히 일치해야 합니다.

`my-first-firefox-extension/manifest.json`의 다음 항목도 변경합니다.

```json
"host_permissions": ["https://page-summary.your-subdomain.workers.dev/*"]
```

- 위 URL을 **본인의 Worker 도메인**으로 바꿉니다.
- `host_permissions`는 주소 끝에 `/*`를 붙입니다.
- `OPENAI_API_KEY`는 이 폴더에 적지 마십시오.

## 5. Firefox에 임시 확장 프로그램 설치

1. Firefox 주소창에 **`about:debugging`**을 입력합니다.
2. 왼쪽에서 **This Firefox**를 선택합니다.
3. **Load Temporary Add-on**을 클릭합니다.
4. **`my-first-firefox-extension/manifest.json` 파일**을 선택합니다. `cloudflare` 폴더나 ZIP 파일을 선택하는 단계가 아닙니다.
5. **My First Firefox Extension + LLM**이 **Temporary Extensions** 아래에 나타나면 로드된 것입니다.

**중요:** Firefox를 완전히 종료하면 임시 확장 프로그램이 제거됩니다. 다시 실행하면 위 과정을 반복합니다.

## 6. 예제 실행

1. https://example.com 에 접속합니다.
2. Firefox 우측 상단의 퍼즐 모양 **Extensions** 버튼을 클릭합니다.
3. **My First Firefox Extension + LLM**을 클릭합니다. 확장 프로그램에 따라 메뉴에서 아이콘 클릭/도구 모음 고정이 필요할 수 있습니다.
4. 전송 동의 창에서 **OK**를 누릅니다.
5. 배경색이 연노랑으로 바뀌고, LLM 요청 중에는 확장 프로그램 아이콘에 `…` 배지가 표시됩니다.
6. 응답이 완료되면 한국어 한 문장짜리 페이지 설명을 알림창으로 표시합니다.

**참고:** 처음 실행 시 Firefox에서 Worker 호스트 접근 권한을 요청한다면 허용해야 합니다.

## 7. 변경 후 재로드하기

`background.js` 또는 `manifest.json`을 수정했다면 **`about:debugging → This Firefox → 확장 프로그램의 Reload`**를 클릭합니다. 그 뒤 테스트 웹페이지를 새로고침해 다시 실행합니다.

오류를 확인하려면 `about:debugging`에서 해당 확장 프로그램의 **Inspect**를 클릭해 개발자 도구 콘솔을 확인합니다.

## 8. 오류 해결

| 증상 | 점검 항목 |
| --- | --- |
| `WORKER_URL과 DEMO_TOKEN을 설정하세요` | `background.js` 맨 위 두 상수를 실제 값으로 변경하고 Reload |
| `접속 토큰이 다릅니다` | Worker Secret과 확장 프로그램의 DEMO_TOKEN 일치 여부 |
| `OpenAI HTTP 401` | OpenAI API 키가 유효한지 |
| `OpenAI HTTP 429` | API 결제 설정, 잔액 또는 호출 제한 |
| `Failed to fetch` | Worker URL, Deploy 상태, 정확한 `host_permissions`, Firefox 사이트 권한 |
| `응답 시간이 초과되었습니다` | API 연결 또는 응답 지연. 이미 처리된 요청의 요금은 발생할 수 있음 |
| 클릭해도 반응 없음 | `about:debugging`에서 Reload, 일반 HTTPS 페이지에서 테스트, Inspect 콘솔 확인 |
| 분석 중 다른 페이지로 이동 | 원본과 다른 문서에 결과가 잘못 출력되지 않도록 결과 표시를 중단할 수 있음 |

`about:debugging`, `about:addons`, Firefox 부가 기능 스토어의 일부 페이지 등 **브라우저 보호 페이지**에서는 코드 삽입이 제한됩니다.

## 9. 개인정보와 보안

- 페이지의 **제목과 본문 텍스트 앞부분**이 Cloudflare 및 OpenAI로 전송됩니다. 공개 테스트 페이지에서 사용하십시오.
- `form`, `input`, `textarea`, `select`, 편집 요소, 숨김 요소 등은 추출 대상에서 제외하지만 **일반 본문에 보이는 개인정보는 자동 익명화하지 않습니다.**
- OpenAI API 키는 Worker Secret에만 저장합니다.
- `DEMO_TOKEN`은 로컬 확장 프로그램에서 확인 가능한 값이므로, 실제 서비스의 강력한 사용자 인증으로 사용하면 안 됩니다.
- 공개 배포 시 서버 측 사용자 인증, 요청량 제한, 비용 제한, 동의 흐름을 별도로 구현해야 합니다.
- 알림창은 실습용입니다. **NVDA의 읽기 위치 이동 및 탐색 기능은 이 예제에 포함되지 않습니다.**

## 10. Chrome 예제에서 달라진 부분

| Chrome | Firefox |
| --- | --- |
| `background.service_worker` | `background.scripts` |
| `chrome.action` | `browser.action` |
| `chrome.scripting.executeScript()` | `browser.scripting.executeScript()` |
| `chrome://extensions` | `about:debugging` |
| `Load unpacked`로 폴더 선택 | `Load Temporary Add-on`에서 `manifest.json` 선택 |

LLM 분석 방식, Worker 인증/호출, 본문 추출, 배경색 변경은 원본 예제를 유지했습니다. Mozilla 문서에 따라 Firefox `executeScript`의 결과에 `error`가 있으면 오류 처리하도록 한 부분만 보강했습니다.

## 11. 검증 범위

이 배포 파일은 JSON 파싱, JavaScript 문법 검사 및 모의 브라우저/Web Worker 실행 테스트 대상으로 준비되었습니다. **실제 Firefox UI 실행, Cloudflare 배포, OpenAI API 유료 호출은 사용자의 계정·환경에서 직접 확인해야 합니다.**

## 공식 문서

- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/background
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/executeScript
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/host_permissions
- https://firefox-source-docs.mozilla.org/devtools-user/about_colon_debugging/
- https://developers.cloudflare.com/workers/get-started/dashboard/
- https://developers.cloudflare.com/workers/configuration/secrets/
- https://platform.openai.com/docs/api-reference/responses
