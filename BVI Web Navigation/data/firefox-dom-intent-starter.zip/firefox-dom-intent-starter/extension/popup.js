// Must match the deployed Worker URL and the host permission in manifest.json.
const WORKER_URL = 'https://dom-intent.YOUR-SUBDOMAIN.workers.dev/';
const status = document.querySelector('#status');
const result = document.querySelector('#result');

// This runs inside the currently active web page, without rewriting the DOM.
function extractPageSample() {
  const root = document.querySelector('main') || document.body;
  const tags = 'h1,h2,h3,h4,p,li,a,button,label,img,input,select,textarea';
  const nodes = Array.from(root.querySelectorAll(tags));
  const items = [];
  for (const el of nodes) {
    if (items.length >= 35) break; // Transparent limitation: first 35 visible candidate elements.
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    if (style.display === 'none' || style.visibility === 'hidden' || rect.width <= 0 || rect.height <= 0) continue;
    if (el.closest('[aria-hidden="true"]')) continue;
    if (el.matches('input[type="password"],input[type="hidden"]')) continue;
    const tag = el.tagName.toLowerCase();
    const interactive = /^(input|select|textarea)$/.test(tag);
    const label = interactive
      ? (el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.labels?.[0]?.innerText || '')
      : (tag === 'img' ? (el.getAttribute('alt') || '') : (el.innerText || el.textContent || ''));
    const snippet = label.replace(/\s+/g, ' ').trim().slice(0, 120);
    if (!snippet) continue;
    const container = el.closest('section,article,form,nav,aside,header,footer') || el.parentElement;
    items.push({
      id: `E${items.length + 1}`,
      tag,
      text: snippet,
      role: el.getAttribute('role') || '',
      context: (container?.getAttribute('aria-label') || container?.getAttribute('id') || container?.getAttribute('class') || container?.tagName || '').toString().slice(0, 65),
      visual: {
        x: Math.round(rect.x), y: Math.round(rect.y),
        fontSize: style.fontSize, fontWeight: style.fontWeight,
      }
    });
  }
  return {
    title: document.title.slice(0, 120),
    hostname: location.hostname,
    elements: items,
    total_candidate_elements: nodes.length,
    truncated: nodes.length > items.length
  };
}

function line(parent, text, className) {
  const p = document.createElement('p');
  if (className) p.className = className;
  p.textContent = text;
  parent.appendChild(p);
}

function render(data, page) {
  const r = data.result;
  result.replaceChildren();
  const intro = document.createElement('section');
  line(intro, `추론된 전체 목적: ${r.page_intent}`);
  line(intro, `분석한 요소 ${page.elements.length}개 / 감지된 후보 ${page.total_candidate_elements}개`, 'small');
  if (page.truncated) line(intro, '주의: 첫 35개 요소만 분석한 부분 결과입니다.', 'small');
  result.appendChild(intro);
  const lookup = new Map(r.groups.map(g => [g.id, g]));
  for (const id of r.order) {
    const g = lookup.get(id);
    if (!g) continue;
    const s = document.createElement('section');
    const title = document.createElement('h3');
    title.textContent = `${id} · ${g.label}`;
    s.appendChild(title);
    line(s, `의도: ${g.intent}`);
    line(s, `근거: ${g.evidence}`, 'small');
    line(s, `DOM 요소: ${g.element_ids.join(', ')}`, 'small');
    result.appendChild(s);
  }
  const outro = document.createElement('section');
  line(outro, `순서의 이유: ${r.order_reason}`);
  result.appendChild(outro);
}

document.querySelector('#analyze').addEventListener('click', async () => {
  result.replaceChildren();
  status.textContent = 'DOM 추출 및 AI 분석 중...';
  try {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/^https?:/.test(tab.url || '')) throw new Error('https:// 또는 http:// 웹페이지에서 실행하세요.');
    const execution = await browser.scripting.executeScript({
      target: { tabId: tab.id }, func: extractPageSample
    });
    const page = execution?.[0]?.result;
    if (!page?.elements?.length) throw new Error('분석할 DOM 요소를 찾지 못했습니다.');
    const response = await fetch(WORKER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ page })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || data.error || `HTTP ${response.status}`);
    render(data, page);
    status.textContent = '완료. 그룹과 추천 순서를 표시했습니다. 원본 페이지는 수정하지 않았습니다.';
  } catch (error) {
    status.textContent = `오류: ${error.message}`;
  }
});
