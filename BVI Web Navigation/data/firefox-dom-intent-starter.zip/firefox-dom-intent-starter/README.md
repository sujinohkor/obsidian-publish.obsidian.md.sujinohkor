# DOM Intent Grouping — Firefox + Cloudflare Workers AI tutorial

## 1. Create a new Cloudflare Worker
1. Open https://dash.cloudflare.com/ and create a **new Worker** (do not overwrite Bongsuk Checker).
2. Name it `dom-intent` (or choose another name).
3. Replace the default Worker code with the contents of `worker/worker.js` and deploy.
4. In Worker Settings > Bindings, add **Workers AI** and name the binding exactly `AI`. Deploy again if necessary.
5. Copy its workers.dev URL, e.g. `https://dom-intent.YOUR-SUBDOMAIN.workers.dev/`.

## 2. Set up the Firefox extension
1. In `extension/popup.js`, replace `WORKER_URL` with the exact deployed URL.
2. In `extension/manifest.json`, replace `host_permissions` origin to match the exact worker host, e.g. `https://dom-intent.YOUR-SUBDOMAIN.workers.dev/*`.
3. Open Firefox -> `about:debugging` -> **This Firefox** -> **Load Temporary Add-on** and choose `extension/manifest.json`.
4. Open a *public*, ordinary website that is not an extension or browser internal page.
5. Click the extension icon -> **Analyze current page**.
6. The popup displays inferred communicative purpose, groups, a suggested visiting order, and rationale.

## 3. What this research starter does and does not do
- Yes: reads the CURRENT DOM, takes the first **35 visible candidate nodes**, collects a few contextual and visual features, sends them to Workers AI, and displays intent-based groups and group ordering.
- No: does not reorganize DOM, change page layout, navigate focus, or verify NVDA virtual-cursor behavior.
- The result is a **partial prototype**; analyzing only 35 candidate nodes is not representative of the complete page.
- Avoid personal, authenticated, and sensitive websites: DOM snippets go to the remote AI service.
- No API key is needed inside the extension because Workers AI uses the `AI` Worker binding.
- The Worker URL is **publicly callable**. CORS is NOT authentication. Before public use, configure Cloudflare rate limiting and authentication/access controls. Free Workers AI quota is not unlimited.
- LLM output is checked for missing/duplicate DOM IDs and invalid group order. If output is invalid, the response fails rather than silently inventing navigation.
- Schema-constrained output can occasionally fail; try a simpler public page or fewer nodes first.

## 4. How the criteria are set
- Edit `SYSTEM_PROMPT` in `worker/worker.js`.
- **GROUPING RULES** specify *why elements belong together* based on inferred communicative purposes.
- **ORDERING RULES** specify *how to order the groups* after grouping for a user without a precise task.
- The result is JSON (`page_intent`, `groups`, `order`, `order_reason`).
- `SCHEMA` determines the required output structure, not the semantic grouping criteria.

## Official docs
- https://developers.cloudflare.com/workers-ai/get-started/workers-wrangler/
- https://developers.cloudflare.com/workers-ai/features/json-mode/
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/scripting/executeScript
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/Your_first_WebExtension
