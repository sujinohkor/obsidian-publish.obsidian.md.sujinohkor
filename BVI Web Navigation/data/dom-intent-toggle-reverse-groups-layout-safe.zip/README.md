# DOM Intent Toggle — Reverse Groups, Preserve Internal Order (v0.5.0)

A Firefox extension based on the user-supplied `dom-intent-toggle-reverse-order-layout-safe-popup-fixed(1).zip` and using the same `dom-intent-starter(3).zip` Cloudflare Worker API. The Worker code is unchanged.

## What ON does

1. **Analyze page:** Extract up to 35 visible sibling content blocks from one existing container. Your Cloudflare Workers AI Worker infers communicative-intent groups.
2. **ON · Reverse:** Sort groups by the position of their *first* block in the original DOM. Reverse **only the group order**. For each group, sort its member blocks by their *original DOM index*, never the ordering returned by the LLM. Request the resulting group order in the accessibility tree using `aria-owns` on the selected container.
3. **OFF · Restore:** Remove only the temporary `aria-owns` and automatically generated `id` attributes introduced by the extension. Source HTML, original CSS stylesheets, and physical DOM child positions are untouched.

| | Normal | ON request |
|---|---|---|
| On-screen order | A → B → C | A → B → C |
| Group order for screen reader (requested) | A → B → C | C → B → A |
| Group A's internal order | a → a' → a'' | a → a' → a'' |
| Group B's internal order | b → b' → b'' | b → b' → b'' |
| Group C's internal order | c → c' → c'' | c → c' → c'' |

**Crucial distinction:** This is an **accessibility-order experiment, not actual DOM-node reparenting or physical DOM-node reordering**. The extension DOES modify live DOM attributes (`aria-owns` and temporary `id`s) to *request* a different accessibility-tree order. If the physical DOM children were moved, pages with ordinary CSS flow would often change their visual appearance. Preserving both unchanged original CSS and unchanged visual appearance across arbitrary sites is incompatible with guaranteed physical DOM node reordering. No new webpage, DOM clone, overlay, or separate HTML document is generated.

## Changes in v0.5.0

- Stronger **within-group order invariant**: every member ID is sorted by original DOM position before reversing groups, and `groupInternalOrderPreserved` is validated before and after ON.
- The popup displays **group sequence including all block IDs** before and after ON so you can see exactly whether only whole groups were reversed.
- Geometry and selected computed-CSS properties are checked on the container, blocks and representative descendant elements. Unexpected changes trigger immediate rollback of our attributes.
- Popup retains its fixed **440px width**, avoiding the previous narrow vertical-text issue.
- Clearer distinction between **original physical DOM child order**, **requested accessibility order**, and **actual unverified Firefox+NVDA speech**.

## Setup (Firefox)

1. Extract the ZIP.
2. Edit `extension/popup.js`: replace `WORKER_URL` with your existing Cloudflare Worker URL.
3. Edit `extension/manifest.json`: replace the `host_permissions` URL with the exact Worker origin followed by `/*`.
4. In Firefox, open `about:debugging` → **This Firefox** → **Load Temporary Add-on** → select `extension/manifest.json`.
5. Disable older DOM Intent extensions in Firefox while testing so that two experiments do not interfere.
6. Use an ordinary `https://` or `http://` page. The extension cannot run in Firefox's built-in privileged pages.

You **do not need to redeploy the Cloudflare Worker**. The `worker/worker.js` inside this ZIP is unchanged and included for reference only.

## Verification procedure (Firefox + NVDA)

1. Open a page with several content blocks. Click **Analyze page**.
2. In the popup, confirm **OFF group order** and **ON reversed groups**. Confirm that each group's member IDs stay in forward order, for example `G1 (E1 → E2 → E3)`.
3. With **OFF**, return to the page. Open NVDA **Tools → Speech Viewer**. Press `NVDA+F5` to refresh its browse-mode document, `Ctrl+Home`, then `NVDA+Down Arrow` (Say All). Record content order.
4. Click **ON · Reverse**. The visible page should look exactly the same. Check that the popup reports ARIA applied, original DOM order unchanged, and sampled appearance unchanged.
5. Repeat `NVDA+F5`, `Ctrl+Home`, Say All, and compare actual spoken order with the requested sequence.
6. Click **OFF · Restore** and repeat; the original reading order should return.

**NVDA result not guaranteed:** The popup verifies only the attributes and a *requested* accessibility ordering; it cannot inspect Firefox's full accessibility tree or NVDA's virtual cursor/speech. A page might not honor `aria-owns` on existing children. If ON does not change NVDA speech, that is an important feasibility-test result, not proof that physical DOM-node order changed.

## Known limitations

- `aria-owns` is **discouraged by MDN** for rearranging existing DOM children. It may also misalign screen-reader reading order and Tab-keyboard focus order. This is a **research diagnostic, not a production accessibility solution**.
- This is a *sample-based* test: only the first 35 eligible direct sibling blocks under one existing parent are grouped. Other blocks keep their physical positions. Groups are not necessarily contiguous in the original DOM, but their members are internally sorted.
- A layout/CSS sample cannot guarantee pixel identity on every external website, especially dynamic sites with attribute-sensitive selectors and animations. On detected appearance changes the extension rolls back. Do not rely on the displayed result as proof without inspecting the page.
- Dynamic websites can change the live DOM or IDs unexpectedly; reload the page to reset when necessary.
- Extracted text/structural features are transmitted to the configured Cloudflare Worker. Avoid private webpages.
- If the AI found only one group, reversal is unavailable.

## Test results

Tests run locally against Chromium with synthetic A/a,a',a''; B/b,b',b''; C/c,c',c'' blocks:

- ON requested C(c,c',c'') → B(b,b',b'') → A(a,a',a''); *all members remained in original within-group order*.
- Chromium's accessibility-tree group order matched the requested reversal.
- Actual DOM node order and stylesheets remained unchanged; ON screenshot matched OFF pixel-by-pixel in this test fixture.
- OFF removed all temporary ARIA/ID attributes and restored the previous state.
- A fixture whose CSS reacted to the injected ARIA attribute correctly triggered automatic rollback.

**Firefox + NVDA have not been executed in this environment.**

## File map

- `extension/manifest.json` — Firefox extension manifest
- `extension/popup.html` — fixed-width popup with detailed group-order verification
- `extension/popup.js` — actions, Worker request, and diagnostics
- `extension/content.js` — grouping, group reversal, ARIA request, layout guard, restoration
- `worker/worker.js` — unchanged Worker source, included only as a reference

References:
- MDN `aria-owns`: https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Attributes/aria-owns
- WAI-ARIA 1.2: https://www.w3.org/TR/wai-aria/#aria-owns
