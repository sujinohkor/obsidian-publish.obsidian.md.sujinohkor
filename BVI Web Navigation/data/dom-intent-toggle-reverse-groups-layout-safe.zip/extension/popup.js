// Configure both this URL and manifest.json > host_permissions.
// Keep using your existing dom-intent Cloudflare Worker; no redeployment needed.
const WORKER_URL = 'https://dom-intent.YOUR-SUBDOMAIN.workers.dev/';
const KIND = 'DOM_INTENT_REVERSE_GROUPS_ARIA_V2';

const el = selector => document.querySelector(selector);
const analyzeButton = el('#analyze');
const onButton = el('#on');
const offButton = el('#off');
const modeNode = el('#mode');
const statusNode = el('#status');
const verificationPanel = el('#verification');
const aiPanel = el('#ai-panel');
let busy = false;
let view = { analyzed: false, enabled: false, canReverse: false };

function formatOrder(values) {
  return values.length ? values.join(' → ') : '(none)';
}

function addText(parent, text, className) {
  const paragraph = document.createElement('p');
  paragraph.textContent = text;
  if (className) paragraph.className = className;
  parent.appendChild(paragraph);
}

function render(state) {
  if (state) view = state;
  analyzeButton.disabled = busy || !!view.enabled;
  onButton.disabled = busy || !view.analyzed || !!view.enabled || !view.canReverse;
  offButton.disabled = busy || !view.enabled;
  onButton.setAttribute('aria-pressed', String(!!view.enabled));
  offButton.setAttribute('aria-pressed', String(!!view.analyzed && !view.enabled));
  modeNode.textContent = !view.analyzed ? 'Mode: not analyzed' :
    view.enabled ? 'Mode: ON — ARIA accessibility-order reversal (visual layout unchanged)' :
      'Mode: OFF — original accessibility order';

  verificationPanel.hidden = !view.analyzed;
  aiPanel.hidden = !view.analyzed;
  if (!view.analyzed) return;

  el('#original-groups').textContent = formatOrder(view.originalGroupOrder);
  el('#reverse-groups').textContent = formatOrder(view.reverseGroupOrder);
  const memberById = new Map((view.groupMembers || []).map(g => [g.id, g.elementIds]));
  const formatGroups = order => order.map(id =>
    `${id} (${(memberById.get(id) || []).join(' → ')})`
  ).join('  →  ');
  el('#original-members').textContent = formatGroups(view.originalGroupOrder);
  el('#reverse-members').textContent = formatGroups(view.reverseGroupOrder);
  const inner = el('#internal-order-check');
  inner.className = view.groupInternalOrderPreserved ? 'good' : 'bad';
  inner.textContent = view.groupInternalOrderPreserved ?
    'PASS: each group keeps its original internal order.' :
    'FAIL: a group internal order was changed.';
  el('#actual-elements').textContent =
    `Physical DOM node order (unchanged): ${formatOrder(view.observedElementOrder)}`;
  el('#requested-order').textContent =
    `Requested screen-reader block sequence (unverified): ${formatOrder(view.requestedAccessibilityOrder)}`;
  const verified = el('#dom-verified');
  verified.className = view.domUnchanged && view.groupInternalOrderPreserved && (!view.enabled || (view.ariaOwnsApplied && view.layoutUnchanged)) ? 'good' : 'bad';
  verified.textContent = !view.domUnchanged ?
    'DOM changed unexpectedly — reload the webpage.' :
    view.enabled ?
      (view.ariaOwnsApplied && view.layoutUnchanged ?
        'ARIA set · physical DOM order unchanged · sampled visual layout and CSS unchanged (NVDA not yet verified)' :
        'ARIA/layout verification FAILED — turn OFF.') :
      'OFF · Original DOM order retained. No ARIA override.';

  const page = view.page;
  el('#sample-count').textContent =
    `${page.elements.length} sampled sibling blocks · ${view.groupCount} inferred groups` +
    (page.truncated ? ' · Partial sample: first 35 blocks only' : '');
  el('#page-intent').textContent = `Inferred page intent: ${view.result.page_intent}`;

  const list = el('#groups');
  list.replaceChildren();
  const groupById = new Map(view.result.groups.map(group => [group.id, group]));
  for (const groupId of view.originalGroupOrder) {
    const group = groupById.get(groupId);
    if (!group) continue;
    const container = document.createElement('div');
    container.className = 'group';
    const heading = document.createElement('strong');
    heading.textContent = `${groupId} · ${group.label}`;
    container.appendChild(heading);
    addText(container, `Intent: ${group.intent}`);
    addText(container, `Blocks: ${group.element_ids.join(', ')}`, 'muted');
    list.appendChild(container);
  }
}

async function activeTab() {
  const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/^https?:/i.test(tab.url || '')) {
    throw new Error('Open an ordinary HTTP(S) webpage before using this extension.');
  }
  return tab;
}

async function command(tabId, name, extra = {}) {
  const payload = { kind: KIND, command: name, ...extra };
  let response;
  try {
    response = await browser.tabs.sendMessage(tabId, payload);
  } catch {
    await browser.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
    response = await browser.tabs.sendMessage(tabId, payload);
  }
  if (!response?.ok) throw new Error(response?.error || 'The webpage did not respond.');
  return response;
}

async function run(work) {
  if (busy) return;
  busy = true;
  render();
  try {
    await work();
  } catch (error) {
    statusNode.textContent = `Error: ${error.message}`;
  } finally {
    busy = false;
    render();
  }
}

analyzeButton.addEventListener('click', () => run(async () => {
  const tab = await activeTab();
  statusNode.textContent = 'Extracting content blocks and inferring designer intent...';
  const { page, nonce } = await command(tab.id, 'EXTRACT');
  if (!page?.elements?.length) throw new Error('No readable content blocks found.');

  const response = await fetch(WORKER_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ page })
  });
  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error(`Cloudflare Worker returned a non-JSON response (HTTP ${response.status}).`);
  }
  if (!response.ok) throw new Error(result.detail || result.error || `HTTP ${response.status}`);
  const current = await activeTab();
  if (current.id !== tab.id) throw new Error('The active tab changed. Analyze again.');

  render(await command(tab.id, 'SET_ANALYSIS', { nonce, result: result.result }));
  statusNode.textContent = view.canReverse ?
    'Analysis complete. ON will reverse GROUP order, not each group’s internal element order.' :
    'Analysis complete, but only one group was found. No group reversal is possible.';
}));

onButton.addEventListener('click', () => run(async () => {
  const tab = await activeTab();
  render(await command(tab.id, 'ON'));
  statusNode.textContent = view.domUnchanged && view.ariaOwnsApplied && view.layoutUnchanged ?
    'ON: group order reversed in ARIA request; member order preserved. Verify with NVDA (NVDA+F5).' :
    'ON: DOM or ARIA verification failed. Turn OFF.';
}));

offButton.addEventListener('click', () => run(async () => {
  const tab = await activeTab();
  render(await command(tab.id, 'OFF'));
  statusNode.textContent = view.domUnchanged ?
    'OFF: ARIA override removed. Original DOM / reading order requested.' :
    'OFF: page contents changed externally; reload if needed.';
}));

(async () => {
  try {
    const tab = await activeTab();
    render(await command(tab.id, 'GET_STATUS'));
    if (view.analyzed) {
      statusNode.textContent = view.enabled ?
        'ON is active in this tab. ARIA reverse requested; compare NVDA Speech Viewer.' :
        'Analysis available for this tab. You can switch ON.';
    }
  } catch (error) {
    statusNode.textContent = `Unavailable: ${error.message}`;
  }
})();
