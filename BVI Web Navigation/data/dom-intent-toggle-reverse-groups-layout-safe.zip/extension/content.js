// DOM Intent Toggle - Reverse Groups, Preserve Within-Group Order.
// Experiment: change the LIVE DOM's accessibility-related attributes, not the
// underlying page source or physical DOM child order. The goal is to request
// C(c,c',c'') -> B(b,b',b'') -> A(a,a',a'') from a page A,B,C while leaving
// the rendered page visually identical. Actual Firefox+NVDA speech is unproven.
// aria-owns is an experimental ordering technique, NOT recommended for production.
(() => {
  const GUARD = '__DOM_INTENT_REVERSE_GROUPS_ARIA_V2__';
  if (globalThis[GUARD]) return;
  globalThis[GUARD] = true;

  const MAX_UNITS = 35; // Existing Cloudflare Worker supports 1-35 elements.
  const MAX_ARIA_CHILDREN = 100; // Prevent unbounded ownership lists.
  const MESSAGE_KIND = 'DOM_INTENT_REVERSE_GROUPS_ARIA_V2';
  const excluded = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'LINK', 'META', 'BR',
    'IFRAME', 'OBJECT', 'EMBED', 'SVG', 'CANVAS'
  ]);

  let session = null;
  let nonceCounter = 0;

  function isVisible(el) {
    if (!el || excluded.has(el.tagName)) return false;
    if (el.closest('[aria-hidden="true"], [inert]')) return false;
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== 'none' && style.visibility !== 'hidden' &&
      rect.width > 0 && rect.height > 0;
  }

  function summarize(el) {
    const label = el.getAttribute('aria-label') || '';
    const alt = el.tagName === 'IMG' ? (el.getAttribute('alt') || '') : '';
    const heading = el.querySelector('h1,h2,h3,h4,h5,h6');
    const text = [label, alt, el.innerText || el.textContent || '']
      .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
    return {
      text: text.slice(0, 450),
      heading: (heading?.innerText || heading?.textContent || '')
        .replace(/\s+/g, ' ').trim().slice(0, 85)
    };
  }

  function candidateChildren(parent) {
    return Array.from(parent.children).filter(el =>
      isVisible(el) && summarize(el).text.length > 0
    );
  }

  // Keep the original v0.2 scope strategy: siblings under one parent.
  // This avoids breaking nested controls and section relationships.
  function chooseScope() {
    const root = document.querySelector('main') ||
      document.querySelector('[role="main"]') ||
      document.querySelector('article') || document.body;
    if (!root) throw new Error('No readable content root found.');
    let parent = root;
    for (let depth = 0; depth < 7; depth += 1) {
      const candidates = candidateChildren(parent);
      if (candidates.length >= 2) {
        return {
          parent,
          units: candidates.slice(0, MAX_UNITS),
          total: candidates.length
        };
      }
      const visibleChildren = Array.from(parent.children).filter(isVisible);
      if (visibleChildren.length !== 1) break;
      parent = visibleChildren[0];
    }
    throw new Error('At least two readable sibling content blocks are required.');
  }

  function selectedIdsInLiveDom() {
    if (!session) return [];
    const ids = new Map(session.units.map((node, index) => [node, `E${index + 1}`]));
    return Array.from(session.parent.children)
      .filter(node => ids.has(node))
      .map(node => ids.get(node));
  }

  function validOriginalPosition() {
    if (!session || !session.parent.isConnected ||
      !session.units.every(node => node.isConnected && node.parentNode === session.parent)) {
      return false;
    }
    // Prevent applying stale analysis if a dynamic page reordered the content.
    const actual = selectedIdsInLiveDom();
    const original = session.page.elements.map(item => item.id);
    return actual.length === original.length &&
      actual.every((id, index) => id === original[index]) &&
      session.originalChildren.length === session.parent.children.length &&
      session.originalChildren.every((node, index) => session.parent.children[index] === node);
  }

  function extract() {
    if (session?.enabled) throw new Error('Turn OFF before analyzing this page again.');
    const { parent, units, total } = chooseScope();
    const elements = units.map((element, index) => {
      const style = getComputedStyle(element);
      const rect = element.getBoundingClientRect();
      const { text, heading } = summarize(element);
      return {
        id: `E${index + 1}`,
        tag: element.tagName.toLowerCase(),
        text,
        heading,
        role: element.getAttribute('role') || '',
        context: [
          parent.tagName.toLowerCase(),
          parent.getAttribute('aria-label') || '',
          (parent.id || '').slice(0, 45),
          (typeof element.className === 'string' ? element.className : '').slice(0, 55)
        ].filter(Boolean).join(' / ').slice(0, 110),
        visual: {
          x: Math.round(rect.x), y: Math.round(rect.y),
          fontSize: style.fontSize, fontWeight: style.fontWeight
        }
      };
    });
    const page = {
      title: document.title.slice(0, 120),
      hostname: location.hostname,
      elements,
      total_candidate_elements: total,
      truncated: total > MAX_UNITS,
      sampling_note: 'Readable direct sibling content blocks under one existing DOM parent.'
    };
    session = {
      nonce: ++nonceCounter,
      parent,
      units,
      originalChildren: Array.from(parent.children),
      page,
      result: null,
      groupsInOriginalOrder: [],
      reverseGroupOrder: [],
      membersByGroup: [],
      reverseElementOrder: [],
      enabled: false,
      ownedValue: null,
      generatedIds: [],
      layoutUnchanged: null
    };
    return { nonce: session.nonce, page };
  }

  function setAnalysis({ nonce, result }) {
    if (!session || nonce !== session.nonce) {
      throw new Error('Analysis expired. Analyze this page again.');
    }
    if (session.enabled) throw new Error('Turn OFF before replacing the analysis.');
    if (!validOriginalPosition()) {
      throw new Error('The page DOM changed during analysis. Analyze again.');
    }
    if (!result || !Array.isArray(result.groups) || !Array.isArray(result.order)) {
      throw new Error('Workers AI did not provide groups and an order.');
    }

    const elementIds = session.page.elements.map(item => item.id);
    const indexOf = new Map(elementIds.map((id, index) => [id, index]));
    const seenIds = new Set();
    const groupIds = new Set();
    const orderedGroups = [];

    for (const group of result.groups) {
      if (!group || typeof group.id !== 'string' || !group.id ||
        groupIds.has(group.id) || !Array.isArray(group.element_ids) ||
        group.element_ids.length === 0) {
        throw new Error('Invalid or duplicate AI group.');
      }
      groupIds.add(group.id);
      for (const id of group.element_ids) {
        if (!indexOf.has(id) || seenIds.has(id)) {
          throw new Error(`Unknown or duplicate element: ${id}`);
        }
        seenIds.add(id);
      }
      const ids = [...group.element_ids]
        .sort((a, b) => indexOf.get(a) - indexOf.get(b));
      orderedGroups.push({
        id: group.id,
        firstIndex: indexOf.get(ids[0]),
        elementIds: ids
      });
    }
    if (seenIds.size !== elementIds.length ||
      result.order.length !== groupIds.size ||
      new Set(result.order).size !== groupIds.size ||
      result.order.some(id => !groupIds.has(id))) {
      throw new Error('AI result does not cover the sampled blocks exactly once.');
    }

    // Crucial distinction from v0.2:
    // The LLM's suggested exploratory order is NOT used for the toggle.
    // Sort AI groups by their FIRST original DOM occurrence, then reverse those
    // groups. Preserve original DOM order WITHIN each group.
    orderedGroups.sort((a, b) => a.firstIndex - b.firstIndex);
    const reverseGroups = [...orderedGroups].reverse();
    session.groupsInOriginalOrder = orderedGroups.map(group => group.id);
    session.reverseGroupOrder = reverseGroups.map(group => group.id);
    session.reverseElementOrder = reverseGroups.flatMap(group => group.elementIds);
    session.membersByGroup = orderedGroups.map(group => ({
      id: group.id,
      elementIds: [...group.elementIds]
    }));

    // Test the invariant explicitly: group reversal must NEVER reverse the
    // elements inside a group. Original DOM index determines internal order,
    // regardless of the (untrusted) LLM's element_ids array order.
    if (!reverseGroups.every(group =>
      group.elementIds.every((id, i) => i === 0 ||
        indexOf.get(group.elementIds[i - 1]) < indexOf.get(id))
    )) throw new Error('Group internal order verification failed.');
    session.result = result;
    return getStatus();
  }

  function layoutSample() {
    // Check geometry and important computed CSS properties. Attribute selectors
    // such as [id] or [aria-owns] can change a page's appearance even when no
    // CSS stylesheet or DOM node is moved.
    const nodes = [document.documentElement, document.body, session.parent];
    for (const unit of session.units) {
      nodes.push(unit);
      // A bounded representative subtree sample makes typography changes
      // detectable without scanning enormous sites in a popup operation.
      nodes.push(...Array.from(unit.querySelectorAll('*')).slice(0, 8));
    }
    return Array.from(new Set(nodes.filter(Boolean))).map(node => {
      const r = node.getBoundingClientRect();
      const css = getComputedStyle(node);
      const keys = [
        'display', 'visibility', 'opacity', 'position', 'transform',
        'color', 'backgroundColor', 'fontFamily', 'fontSize', 'fontWeight',
        'lineHeight', 'letterSpacing', 'textAlign', 'order', 'zIndex',
        'outlineColor', 'outlineWidth'
      ];
      return {
        node, rect: [r.x, r.y, r.width, r.height],
        css: keys.map(k => String(css[k]))
      };
    });
  }

  function sameLayout(before, after) {
    return before.length === after.length && before.every((a, i) => {
      const b = after[i];
      return a.node === b.node &&
        a.rect.every((v, j) => Math.abs(v - b.rect[j]) < 0.5) &&
        a.css.every((v, j) => v === b.css[j]);
    });
  }

  function makeUsableId(node, generated) {
    const current = node.getAttribute('id');
    if (current) {
      if (/\s/.test(current) || document.getElementById(current) !== node) {
        throw new Error('The page has ambiguous IDs; the accessibility-order test is unsafe here.');
      }
      return current;
    }
    // Add only temporary IDs when needed. Existing IDs are never changed.
    let id;
    do {
      const bytes = new Uint8Array(12);
      crypto.getRandomValues(bytes);
      id = `dom-intent-ax-${Array.from(bytes, v => v.toString(16).padStart(2, '0')).join('')}`;
    } while (document.getElementById(id));
    node.setAttribute('id', id);
    generated.push({ node, id });
    return id;
  }

  function anyConflictingOwner() {
    // A DOM node may not have two distinct aria-owns owners.
    const targets = new Set(session.originalChildren.filter(n => n.id).map(n => n.id));
    for (const element of document.querySelectorAll('[aria-owns]')) {
      if (element === session.parent) continue;
      const values = (element.getAttribute('aria-owns') || '').trim().split(/\s+/);
      if (values.some(value => targets.has(value))) return true;
    }
    return false;
  }

  function restore() {
    if (!session?.enabled && !session?.generatedIds.length) return;
    const { parent, ownedValue, generatedIds } = session;
    // Never overwrite a site's modification if it changed aria-owns after ON.
    if (parent.getAttribute('aria-owns') !== ownedValue) {
      throw new Error('The website modified aria-owns. Reload the webpage to reset this test.');
    }
    parent.removeAttribute('aria-owns');
    for (const { node, id } of generatedIds) {
      if (node.getAttribute('id') === id) node.removeAttribute('id');
    }
    session.generatedIds = [];
    session.ownedValue = null;
    session.enabled = false;
    session.layoutUnchanged = null;
  }

  function switchOn() {
    if (!session?.result) throw new Error('Click Analyze page first.');
    if (session.enabled) return getStatus();
    if (session.groupsInOriginalOrder.length < 2) {
      throw new Error('AI found only one group. No visible reverse-order test is possible.');
    }
    if (!validOriginalPosition()) {
      throw new Error('The page DOM changed. Analyze again.');
    }
    if (session.originalChildren.length > MAX_ARIA_CHILDREN) {
      throw new Error('Too many sibling nodes for this safe accessibility experiment.');
    }
    if (session.parent.hasAttribute('aria-owns')) {
      throw new Error('This page already uses aria-owns on the chosen container. Refusing to overwrite it.');
    }
    if (anyConflictingOwner()) {
      throw new Error('Some page elements already have another ARIA owner. Refusing to interfere.');
    }

    const before = layoutSample();
    const byId = new Map(session.units.map((node, index) => [`E${index + 1}`, node]));
    const reversed = session.reverseElementOrder.map(id => byId.get(id));
    if (reversed.length !== session.units.length || reversed.some(node => !node)) {
      throw new Error('Invalid reversed group plan.');
    }

    // Keep all unsampled sibling blocks in their original DOM slots.
    // Replace ONLY the sampled slots in a projected accessibility order.
    const selected = new Set(session.units);
    const desiredChildren = [];
    let next = 0;
    for (const child of session.originalChildren) {
      desiredChildren.push(selected.has(child) ? reversed[next++] : child);
    }
    if (next !== reversed.length || new Set(desiredChildren).size !== desiredChildren.length) {
      throw new Error('The computed accessibility order is not a valid permutation.');
    }

    const generated = [];
    try {
      const desiredIds = desiredChildren.map(node => makeUsableId(node, generated));
      const value = desiredIds.join(' ');
      // ARIA 1.2: when direct DOM children are listed in aria-owns, the
      // user agent can order them as listed in the ACCESSIBILITY tree.
      // The real DOM children and visual layout stay in original positions.
      session.parent.setAttribute('aria-owns', value);
      if (!sameLayout(before, layoutSample()) || !validOriginalPosition()) {
        throw new Error('Layout or DOM changed after ARIA attributes; cancelling ON.');
      }
      session.generatedIds = generated;
      session.ownedValue = value;
      session.layoutUnchanged = true;
      session.enabled = true;
      return getStatus();
    } catch (error) {
      // Roll back our own changes even on partial failure.
      session.parent.removeAttribute('aria-owns');
      for (const { node, id } of generated) {
        if (node.getAttribute('id') === id) node.removeAttribute('id');
      }
      session.generatedIds = [];
      session.ownedValue = null;
      session.layoutUnchanged = null;
      session.enabled = false;
      throw error;
    }
  }

  function switchOff() {
    if (session?.enabled) restore();
    return getStatus();
  }

  function getStatus() {
    const analyzed = !!session?.result;
    const original = session?.page.elements.map(item => item.id) || [];
    const live = session ? selectedIdsInLiveDom() : [];
    const unchanged = analyzed && live.length === original.length &&
      live.every((id, i) => id === original[i]) &&
      session.originalChildren.length === session.parent.children.length &&
      session.originalChildren.every((node, i) => session.parent.children[i] === node);
    return {
      analyzed,
      enabled: !!session?.enabled,
      canReverse: analyzed && session.groupsInOriginalOrder.length >= 2,
      groupCount: analyzed ? session.groupsInOriginalOrder.length : 0,
      page: analyzed ? session.page : null,
      result: analyzed ? session.result : null,
      originalGroupOrder: analyzed ? session.groupsInOriginalOrder : [],
      reverseGroupOrder: analyzed ? session.reverseGroupOrder : [],
      groupMembers: analyzed ? session.membersByGroup : [],
      groupInternalOrderPreserved: analyzed && session.membersByGroup.every(group => {
        const indexes = group.elementIds.map(id => original.indexOf(id));
        return indexes.every((index, i) => index >= 0 &&
          (i === 0 || indexes[i - 1] < index));
      }),
      originalElementOrder: original,
      reverseElementOrder: analyzed ? session.reverseElementOrder : [],
      observedElementOrder: live,
      domUnchanged: unchanged,
      layoutUnchanged: session?.layoutUnchanged === true,
      ariaOwnsApplied: !!(session?.enabled && session.ownedValue &&
        session.parent.getAttribute('aria-owns') === session.ownedValue),
      // This is only the *requested* accessibility order. It is NOT proof
      // of the live Firefox accessibility tree, or NVDA's speech order.
      requestedAccessibilityOrder: session?.enabled ? session.reverseElementOrder : original,
      // The physical DOM order intentionally remains original; this sequence
      // is an aria-owns REQUEST, not a Firefox AX tree or NVDA observation.
      testMechanism: 'aria-owns'
    };
  }

  browser.runtime.onMessage.addListener(message => {
    if (!message || message.kind !== MESSAGE_KIND) return undefined;
    try {
      let value;
      switch (message.command) {
        case 'GET_STATUS': value = getStatus(); break;
        case 'EXTRACT': value = extract(); break;
        case 'SET_ANALYSIS': value = setAnalysis(message); break;
        case 'ON': value = switchOn(); break;
        case 'OFF': value = switchOff(); break;
        default: throw new Error('Unknown command.');
      }
      return Promise.resolve({ ok: true, ...value });
    } catch (error) {
      return Promise.resolve({ ok: false, error: String(error?.message || error) });
    }
  });
})();
