// 아래 두 값만 수정하세요. OpenAI API 키를 여기에 넣으면 안 됩니다.
const WORKER_URL = "https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev";
const DEMO_TOKEN = "PASTE_YOUR_RANDOM_DEMO_TOKEN";
const busyTabs = new Set();

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || busyTabs.has(tab.id)) return;
  busyTabs.add(tab.id);
  let documentId;
  const showMessage = async (message) => {
    await chrome.scripting.executeScript({
      target: documentId
        ? { tabId: tab.id, documentIds: [documentId] }
        : { tabId: tab.id },
      func: (text) => window.alert(text),
      args: [message]
    });
  };

  try {
    if (WORKER_URL.includes("YOUR-") || DEMO_TOKEN.startsWith("PASTE_")) {
      throw new Error("background.js에서 WORKER_URL과 DEMO_TOKEN을 먼저 설정하세요.");
    }
    // 반환된 documentId를 사용해 다른 페이지로 이동했을 때 결과가 잘못 표시되지 않게 합니다.
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const agreed = window.confirm(
          "페이지 제목과 본문 앞부분(최대 6,000자)을 Cloudflare와 OpenAI로 전송합니다.\n" +
          "공개 테스트 페이지에서 사용하세요. 계속할까요?"
        );
        if (!agreed) return null;
        document.body.style.backgroundColor = "#fff3b0";
        const root = document.querySelector("main") ||
          document.querySelector("article") || document.body;
        // 보이는 텍스트 중 입력 폼과 편집 영역은 제외합니다.
        const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        let text = "";
        while (walker.nextNode() && text.length < 6000) {
          const node = walker.currentNode;
          const element = node.parentElement;
          if (!element || element.closest(
            'script,style,noscript,form,input,textarea,select,[contenteditable],'+
            '[hidden],[aria-hidden="true"]'
          )) continue;
          const style = getComputedStyle(element);
          if (style.visibility === "hidden" || style.display === "none" ||
              element.getClientRects().length === 0) continue;
          const value = node.textContent.replace(/\s+/g, " ").trim();
          if (value) text += value + " ";
        }
        return { title: document.title.slice(0, 300), text: text.trim().slice(0, 6000) };
      }
    });
    documentId = injection.documentId;
    const page = injection.result;
    if (!page) return;
    if (!page.text) throw new Error("페이지에서 읽을 수 있는 본문을 찾지 못했습니다.");
    await chrome.action.setBadgeText({ tabId: tab.id, text: "…" });
    await chrome.action.setTitle({ tabId: tab.id, title: "LLM이 페이지를 분석하고 있습니다…" });
    const response = await fetch(WORKER_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${DEMO_TOKEN}`
      },
      body: JSON.stringify(page),
      signal: AbortSignal.timeout(23000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Worker 오류: HTTP ${response.status}`);
    if (typeof data.summary !== "string" || !data.summary.trim()) {
      throw new Error("LLM이 설명을 반환하지 않았습니다.");
    }
    await showMessage("페이지 설명 (본문 앞부분 기준)\n\n" + data.summary);
  } catch (error) {
    const message = error.name === "TimeoutError"
      ? "응답 시간이 초과되었습니다. 잠시 후 다시 시도하세요."
      : error.message;
    console.error("페이지 설명 실패:", message);
    try { await showMessage("오류: " + message); } catch {
      // 제한된 페이지 또는 분석 도중 이동한 페이지에는 알림을 주입하지 않습니다.
      await chrome.action.setBadgeText({ tabId: tab.id, text: "!" }).catch(() => {});
    }
  } finally {
    busyTabs.delete(tab.id);
    await chrome.action.setBadgeText({ tabId: tab.id, text: "" }).catch(() => {});
    await chrome.action.setTitle({ tabId: tab.id, title: "이 페이지 설명하기" }).catch(() => {});
  }
});
