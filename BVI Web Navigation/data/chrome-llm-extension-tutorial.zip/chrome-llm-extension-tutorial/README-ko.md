# Chrome 확장 프로그램 + LLM: 한 문장 페이지 설명

개인 실습용 예제입니다. 현재 페이지의 제목과 본문 앞부분(최대 6,000자)을 Cloudflare Worker를 거쳐 OpenAI에 보내고, 한국어 설명을 알림창에 표시합니다. 배경색 변경 기능도 유지합니다. 서버 설치나 npm 설치는 필요 없습니다.

## 포함 파일

* chrome-my-first-extension/manifest.json: Chrome 설정
* chrome-my-first-extension/background.js: 페이지 추출, 서버 요청, 알림 표시
* cloudflare/worker.js: Cloudflare에 붙여 넣을 서버 코드

## 1\. OpenAI API 준비

https://platform.openai.com/api-keys 에서 API 키를 생성합니다. API 프로젝트에 사용 가능한 크레딧/결제 설정이 필요합니다. ChatGPT 구독과 API 결제는 별도입니다. 키를 채팅이나 확장 프로그램에 넣지 마세요. 모델은 gpt-4.1-mini, Responses API를 사용합니다.

## 2\. Cloudflare Worker 만들기

https://dash.cloudflare.com/ 에 로그인합니다.
Workers \& Pages > Create application > Create Worker 또는 Hello World 시작 항목을 선택해 배포합니다(화면에 따라 이름이 다를 수 있습니다).
만든 Worker의 Edit code에서 기본 코드를 지우고 cloudflare/worker.js 전체를 붙여 넣고 Deploy합니다.
Worker의 HTTPS 주소를 복사합니다. 예: https://page-summary.your-subdomain.workers.dev
이 주소를 브라우저에서 열면 Worker is running이라는 JSON이 표시됩니다. 이는 Worker가 실행된다는 확인이며, LLM 연결 성공을 의미하지는 않습니다.

## 3\. Secret 두 개 설정

Worker > Settings > Variables and Secrets > Add에서 Type을 Secret으로 선택합니다.

* OPENAI\_API\_KEY: 1단계에서 발급한 실제 API 키
* DEMO\_TOKEN: 본인이 새로 생성한 32자 이상의 무작위 영문/숫자 토큰
두 값을 저장하고 Deploy합니다. 비밀번호 관리자의 무작위 비밀번호 생성 기능을 사용할 수 있습니다.
DEMO\_TOKEN은 개인 실습용 Worker 접속 암호이며 OpenAI API 키와 다릅니다.

## 4\. 확장 프로그램 설정

chrome-my-first-extension/background.js의 첫 두 상수를 바꿉니다.

* WORKER\_URL: 실제 Worker HTTPS 주소(마지막 /\* 제외)
* DEMO\_TOKEN: Worker Secret에 넣은 것과 똑같은 토큰
manifest.json의 host\_permissions를 실제 Worker 주소 + /\* 로 바꿉니다.
예: \["https://page-summary.your-subdomain.workers.dev/\*"]
OpenAI API 키는 Cloudflare Secret에만 보관합니다.

## 5\. Chrome 설치

기존 파일은 백업한 뒤 교체해도 되고, 이 예제 폴더를 별도로 로드해도 됩니다.
chrome://extensions > 개발자 모드 켜기 > 압축해제된 확장 프로그램 로드 > my-first-extension 폴더 선택.
이미 로드된 같은 폴더의 파일을 교체했다면 확장 프로그램 카드의 새로고침 버튼을 누릅니다.
ZIP 전체 폴더나 cloudflare 폴더가 아니라 manifest.json이 있는 폴더를 선택하세요.

## 6\. 실행

https://example.com 을 열고 확장 프로그램 아이콘을 누릅니다.
전송 안내를 확인하고 승인하면 배경이 노란색으로 바뀌고, 아이콘에 … 표시가 나타납니다.
응답 후 한국어 한 문장 설명이 알림창으로 나옵니다. 결과 표현은 매번 달라질 수 있습니다.
공개 페이지에서 테스트하세요. 폼/편집 영역을 제외하지만, 일반 본문에 표시된 개인정보까지 자동으로 제거하는 도구는 아닙니다.
chrome:// 페이지, Chrome 웹 스토어, 일부 내장 뷰어에는 사용할 수 없습니다.
분석 도중 다른 페이지로 이동하면 이전 문서 대상 결과는 표시하지 않습니다.

## 오류 해결

* 설정하라는 알림: background.js의 URL과 토큰 수정 후 확장 프로그램 다시 로드.
* 접속 토큰 오류: Worker와 background.js의 DEMO\_TOKEN이 같은지 확인.
* OpenAI HTTP 401: API 키 확인.
* OpenAI HTTP 429: API 크레딧/호출 제한 확인.
* Failed to fetch: Worker 주소, 배포 상태, manifest.json의 host\_permissions 확인.
* 응답 시간 초과: 잠시 후 재시도. 시간 초과 전에 이미 처리된 API 요청은 비용이 발생할 수 있습니다.
* 아무 반응 없음: 일반 HTTPS 페이지에서 실행하고 chrome://extensions의 해당 카드 > 오류 또는 service worker 검사에서 오류 확인.

## 범위와 제한

이것은 부분 텍스트를 이용한 API 연결 연습입니다. 페이지 전체 분석, 시각적 구조 해석, 그룹화, 스크린 리더 호환성 검증은 포함하지 않습니다.
같은 페이지에서 대기 중인 중복 클릭은 막지만, 영속적인 사용자별 사용량 제한은 없습니다.
DEMO\_TOKEN은 로컬 확장 프로그램 코드에서 볼 수 있으므로 토큰이 든 폴더를 공개 배포하지 마세요. 실제 배포에는 사용자 인증과 서버 측 호출량 제한을 추가해야 합니다. Origin 검사나 CORS만으로 인증을 대신할 수 없습니다.
브라우저 콘텐츠 스크립트가 아니라 확장 프로그램 service worker가 정확한 host\_permissions를 사용해 요청하므로 이 예제는 범용 웹사이트용 CORS 허용 코드를 추가하지 않습니다.
알림창은 튜토리얼용입니다. 연구용 인터페이스는 별도 설계와 실제 스크린 리더 테스트가 필요합니다.

## 검증

JavaScript 문법과 Worker의 인증·입력 검증·응답 파싱·API 오류 처리 경로를 모의 API 응답으로 검사했습니다. 실제 API 키를 사용한 호출, Cloudflare 배포, Chrome 실제 실행은 사용자 설정 후 확인해야 합니다.

## 공식 문서

* https://developers.cloudflare.com/workers/get-started/dashboard/
* https://developers.cloudflare.com/workers/configuration/secrets/
* https://developers.openai.com/api/docs/guides/text
* https://developers.openai.com/api/docs/models/gpt-4.1-mini
* https://developer.chrome.com/docs/extensions/develop/concepts/network-requests

