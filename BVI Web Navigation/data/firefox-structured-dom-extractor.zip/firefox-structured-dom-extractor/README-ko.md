# Structured DOM Extractor (Firefox, Manifest V3)

현재 웹페이지의 DOM을 구조화된 JSON으로 내보내는 연구용 프로토타입입니다.

## 설치

1. Firefox 주소창에 `about:debugging` 입력
2. `This Firefox` 선택
3. `Load Temporary Add-on...` 클릭
4. 이 폴더의 `manifest.json` 파일 선택
5. 일반 웹페이지(`https://example.com`, `https://www.wikipedia.org` 등)로 이동
6. 도구 모음의 **Structured DOM Extractor** 아이콘 클릭 → **현재 페이지 분석** → **JSON 저장**

Firefox를 재시작하면 임시 확장 프로그램을 다시 로드해야 할 수 있습니다.

## 추출 결과

- `tree`: 원래 DOM의 계층과 자식 순서를 유지한 JSON 트리 (텍스트 노드 포함)
- `elements`: 주요 의미 요소의 평면 목록 (타입, 태그, CSS selector, 텍스트/라벨 등)
- `stats`: 유형별 개수, 노드 수, 수집 제한 발생 여부
- `page`: 캡처 시각, URL, 문서 제목, 페이지 언어

분류 유형: heading, paragraph, link, button, form_field, image, landmark, list, list_item, table, table_row, table_cell, section, article, form, label, figure, quote, strong, emphasis, iframe, container, text.

`selector`는 분석 당시 DOM의 위치를 나타내는 CSS 선택자입니다. 페이지가 변경되면 동일 요소를 가리키지 않을 수 있습니다.

## 한계 및 보안

1. **DOM ≠ Accessibility Tree**: JSON의 `label`은 DOM 텍스트와 ARIA 등의 속성으로 간단히 추정한 것으로, 브라우저가 계산한 Accessible Name이나 NVDA의 발화 결과와 반드시 일치하지 않습니다.
2. **실행 시점 스냅샷**: 원본 `view-source:` HTML이 아니라 JavaScript 적용 이후의 현재 DOM입니다. 이후 동적으로 변경되는 부분은 자동 갱신되지 않습니다.
3. **비공개 영역**: 교차 출처 iframe의 내부 문서, 폐쇄형 Shadow DOM, 브라우저 내부 페이지, PDF 뷰어 등은 수집하지 않습니다.
4. **숨김 요소**: `display:none`, `visibility:hidden`, `aria-hidden="true"`, `hidden`, `inert` 등의 하위 요소는 제외합니다. 일부 CSS 또는 접근성 조건은 완전히 반영되지 않을 수 있습니다.
5. **안전한 데이터 취급**: 입력 필드의 사용자가 입력한 `value`는 의도적으로 추출하지 않습니다. 하지만 본문에 민감한 개인정보가 있으면 JSON에 포함될 수 있습니다. 민감한 페이지에서는 실행하거나 파일을 공유하지 마세요.
6. 대용량 웹페이지에서는 성능을 위해 최대 12,000개 DOM/텍스트 노드까지만 추출합니다. `stats.truncated`로 확인하세요.
7. 이 버전은 로컬 저장만 합니다. 서버나 LLM으로 데이터를 전송하지 않습니다.

## 파일

- `manifest.json`: 확장 프로그램 설정과 권한
- `popup.html`, `popup.css`, `popup.js`: 실행 UI, 요약 표시 및 JSON 저장
- `extract.js`: 현재 페이지의 DOM 분석 스크립트

## 다음 단계

- DOM 요소를 브라우저 접근성 트리의 역할/이름과 비교하여 보정
- 시각/구조 단서와 콘텐츠 그룹화 모델 연결
- 탐색 그룹으로 이동시키는 기능 추가 (포커스와 스크린리더 읽기 위치 별도 검증)
