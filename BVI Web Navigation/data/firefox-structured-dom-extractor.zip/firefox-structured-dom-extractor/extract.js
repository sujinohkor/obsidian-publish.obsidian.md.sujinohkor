/*
 * Structured DOM Extractor — injected into the active page on demand.
 * Returns a JSON-serializable snapshot (not the browser Accessibility Tree).
 * DOM order, hierarchy and useful CSS selectors are retained.
 */
(() => {
  const MAX_NODES = 12000;
  const MAX_DEPTH = 100;
  const MAX_TEXT_LENGTH = 1000;
  const MAX_LABEL_LENGTH = 300;
  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "META", "LINK"]);
  const LANDMARK_TAGS = new Set(["MAIN", "NAV", "HEADER", "FOOTER", "ASIDE"]);
  const LANDMARK_ROLES = new Set(["main", "navigation", "banner", "contentinfo", "complementary", "search", "region", "form"]);
  const counters = {};
  const elements = [];
  let nodeCount = 0;
  let omittedHidden = 0;
  let truncated = false;

  function compact(value, maxLength = MAX_TEXT_LENGTH) {
    return (value || "").replace(/\s+/g, " ").trim().slice(0, maxLength);
  }

  function selectorFor(element) {
    const parts = [];
    let current = element;
    while (current && current.nodeType === Node.ELEMENT_NODE) {
      const tag = current.localName;
      if (!tag) break;
      let nth = 1;
      for (let prev = current.previousElementSibling; prev; prev = prev.previousElementSibling) {
        if (prev.localName === tag) nth++;
      }
      parts.unshift(`${tag}:nth-of-type(${nth})`);
      current = current.parentElement;
    }
    return parts.join(" > ");
  }

  function hidden(element) {
    if (element.hidden || element.getAttribute("aria-hidden") === "true" || element.hasAttribute("inert")) return true;
    const style = window.getComputedStyle(element);
    return style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse";
  }

  function classify(el) {
    const tag = el.tagName;
    const role = (el.getAttribute("role") || "").trim().toLowerCase().split(/\s+/)[0];
    if (role === "heading" || /^H[1-6]$/.test(tag)) return "heading";
    if (role === "link" || (tag === "A" && el.hasAttribute("href"))) return "link";
    if (role === "button" || tag === "BUTTON") return "button";
    if (["INPUT", "SELECT", "TEXTAREA"].includes(tag) || ["textbox", "checkbox", "radio", "combobox", "spinbutton", "slider", "searchbox", "switch"].includes(role)) return "form_field";
    if (role === "img" || ["IMG", "SVG"].includes(tag)) return "image";
    if (LANDMARK_ROLES.has(role) || LANDMARK_TAGS.has(tag)) return "landmark";
    if (role === "list" || ["UL", "OL", "DL"].includes(tag)) return "list";
    if (role === "listitem" || ["LI", "DT", "DD"].includes(tag)) return "list_item";
    if (role === "table" || tag === "TABLE") return "table";
    if (role === "row" || tag === "TR") return "table_row";
    if (["cell", "columnheader", "rowheader"].includes(role) || ["TH", "TD"].includes(tag)) return "table_cell";
    if (tag === "P" || role === "paragraph") return "paragraph";
    if (tag === "SECTION") return "section";
    if (tag === "ARTICLE") return "article";
    if (tag === "FORM") return "form";
    if (tag === "LABEL") return "label";
    if (["FIGURE", "FIGCAPTION", "CAPTION"].includes(tag)) return "figure";
    if (["BLOCKQUOTE", "Q"].includes(tag)) return "quote";
    if (tag === "STRONG") return "strong";
    if (["EM", "MARK"].includes(tag)) return "emphasis";
    if (tag === "IFRAME") return "iframe";
    return "container";
  }

  function labelFor(el, type) {
    const ariaLabel = compact(el.getAttribute("aria-label"), MAX_LABEL_LENGTH);
    if (ariaLabel) return ariaLabel;

    const labelledBy = el.getAttribute("aria-labelledby");
    if (labelledBy) {
      const label = compact(labelledBy.split(/\s+/).map(id => document.getElementById(id)?.textContent || "").join(" "), MAX_LABEL_LENGTH);
      if (label) return label;
    }

    if (type === "image") return compact(el.getAttribute("alt") || el.getAttribute("title"), MAX_LABEL_LENGTH);
    if (type === "form_field") {
      if (el.id) {
        const associated = Array.from(document.querySelectorAll("label[for]")).find(label => label.htmlFor === el.id);
        if (associated) return compact(associated.textContent, MAX_LABEL_LENGTH);
      }
      const enclosing = el.closest("label");
      if (enclosing) return compact(enclosing.textContent, MAX_LABEL_LENGTH);
      return compact(el.getAttribute("placeholder") || el.getAttribute("title"), MAX_LABEL_LENGTH);
    }
    // This is DOM-derived text, not the browser's computed accessible name.
    if (type !== "container" && type !== "section" && type !== "article") {
      let label = compact(el.innerText || el.textContent, MAX_LABEL_LENGTH);
      if (!label && type === "link") {
        label = compact(Array.from(el.querySelectorAll("img[alt]")).map(img => img.alt).join(" "), MAX_LABEL_LENGTH);
      }
      return label;
    }
    return "";
  }

  function visit(el, depth, parentId) {
    if (nodeCount >= MAX_NODES || depth > MAX_DEPTH) {
      truncated = true;
      return null;
    }
    if (SKIP_TAGS.has(el.tagName) || hidden(el)) {
      omittedHidden++;
      return null;
    }

    const id = ++nodeCount;
    const type = classify(el);
    const tag = el.localName;
    const explicitRole = el.getAttribute("role") || null;
    const node = {
      id,
      parentId,
      tag,
      type,
      selector: selectorFor(el),
      children: []
    };

    if (explicitRole) node.explicitRole = explicitRole;
    const label = labelFor(el, type);
    if (label) node.label = label;
    if (type === "heading") {
      const level = /^h[1-6]$/.test(tag) ? Number(tag.slice(1)) : Number(el.getAttribute("aria-level"));
      if (Number.isInteger(level) && level > 0) node.level = level;
    }
    if (type === "link" && el.getAttribute("href")) node.href = el.getAttribute("href");
    if (type === "form_field") {
      node.inputType = el.getAttribute("type") || tag;
      // Deliberately do not collect input value, checked text, password, or other user-entered values.
    }
    if (type === "image" && el.hasAttribute("alt")) node.alt = el.getAttribute("alt");
    if (type === "table_cell" && el.hasAttribute("scope")) node.scope = el.getAttribute("scope");

    counters[type] = (counters[type] || 0) + 1;
    if (type !== "container") {
      elements.push({
        id,
        parentId,
        type,
        tag,
        selector: node.selector,
        ...(node.level ? { level: node.level } : {}),
        ...(node.label ? { label: node.label } : {}),
        ...(node.explicitRole ? { explicitRole: node.explicitRole } : {}),
        ...(node.href ? { href: node.href } : {})
      });
    }

    // Preserve the original order, including text nodes inside generic wrappers.
    // Text leaf nodes make nested heading composition (e.g. span + strong) inspectable.
    for (const child of el.childNodes) {
      if (nodeCount >= MAX_NODES) { truncated = true; break; }
      if (child.nodeType === Node.ELEMENT_NODE) {
        const descendant = visit(child, depth + 1, id);
        if (descendant) node.children.push(descendant);
      } else if (child.nodeType === Node.TEXT_NODE) {
        const value = compact(child.nodeValue);
        if (value) {
          const textId = ++nodeCount;
          node.children.push({ id: textId, parentId: id, type: "text", text: value });
          counters.text = (counters.text || 0) + 1;
        }
      }
    }
    return node;
  }

  const tree = visit(document.body, 0, null);
  return {
    format: "structured-dom-v1",
    capturedAt: new Date().toISOString(),
    page: { title: document.title, url: location.href, language: document.documentElement.lang || null },
    settings: { maxNodes: MAX_NODES, maxDepth: MAX_DEPTH, maxTextLength: MAX_TEXT_LENGTH, hiddenSubtreesExcluded: true },
    stats: { totalNodes: nodeCount, semanticElements: elements.length, skippedSubtrees: omittedHidden, truncated, counts: counters },
    elements,
    tree
  };
})();
