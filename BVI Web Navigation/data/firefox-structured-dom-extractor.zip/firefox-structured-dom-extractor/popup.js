let extracted = null;
const extractButton = document.getElementById("extract");
const downloadButton = document.getElementById("download");
const status = document.getElementById("status");
const results = document.getElementById("results");

function setStatus(message, isError = false) {
  status.textContent = message;
  status.classList.toggle("error", isError);
}

function render(data) {
  results.hidden = false;
  document.getElementById("meta").textContent = `${data.page.title || "(제목 없음)"} — DOM 노드 ${data.stats.totalNodes.toLocaleString("ko-KR")}개, 분류된 요소 ${data.stats.semanticElements.toLocaleString("ko-KR")}개`;
  const counts = document.getElementById("counts");
  counts.replaceChildren();
  for (const [type, number] of Object.entries(data.stats.counts).sort((a, b) => b[1] - a[1])) {
    if (type === "container" || type === "text") continue;
    const item = document.createElement("div");
    item.className = "count";
    const label = document.createElement("span");
    label.textContent = type;
    const value = document.createElement("strong");
    value.textContent = number.toLocaleString("ko-KR");
    item.append(label, value);
    counts.append(item);
  }

  const preview = document.getElementById("preview");
  preview.replaceChildren();
  for (const entry of data.elements.slice(0, 25)) {
    const li = document.createElement("li");
    const type = document.createElement("span");
    type.className = "type";
    type.textContent = `[${entry.type}]`;
    const desc = document.createTextNode(` ${entry.label || entry.tag}${entry.level ? ` (level ${entry.level})` : ""}`);
    li.append(type, desc);
    preview.append(li);
  }
}

extractButton.addEventListener("click", async () => {
  extracted = null;
  downloadButton.disabled = true;
  results.hidden = true;
  extractButton.disabled = true;
  setStatus("현재 웹페이지를 분석하고 있습니다…");
  try {
    const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("활성 탭을 찾지 못했습니다.");
    const execution = await browser.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["extract.js"]
    });
    const data = execution?.[0]?.result;
    if (!data || data.format !== "structured-dom-v1") throw new Error("DOM 추출 결과가 비어 있습니다.");
    extracted = data;
    downloadButton.disabled = false;
    render(data);
    setStatus(data.stats.truncated
      ? `분석 완료. 너무 큰 페이지여서 ${data.settings.maxNodes}개 노드까지만 수집했습니다.`
      : "분석 완료. 아래에서 확인하거나 JSON으로 저장하세요.");
  } catch (error) {
    setStatus(`분석 실패: ${error.message || error}. 일반 웹페이지(https://)에서 실행해 보세요.`, true);
  } finally {
    extractButton.disabled = false;
  }
});

downloadButton.addEventListener("click", () => {
  if (!extracted) return;
  const json = JSON.stringify(extracted, null, 2);
  const url = URL.createObjectURL(new Blob([json], { type: "application/json;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `structured-dom-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  setStatus("JSON 다운로드를 요청했습니다. 저장한 파일에는 웹페이지의 텍스트가 포함될 수 있습니다.");
});
